package LMS_Project;

import java.util.ArrayList;

public class School
{
	
	ArrayList<student> students = new ArrayList<>();
	ArrayList<admin> admins = new ArrayList<>();
	
	public School(){
	
	}
}
